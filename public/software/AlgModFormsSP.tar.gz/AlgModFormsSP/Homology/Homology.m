

//Working with tuples of lattices:

intrinsic UStab(F::Tup)->Grp
 {Computes the pointwise stabilizer of the tuple of lattices F}
 return &meet [UStab(x): x in F];
end intrinsic;

intrinsic IsUIsomorphic(F1::Tup,F2::Tup:Isometry:=true)->BoolElt
 {Tests whether the HermLats in F1 and F2 are simultaneously isomorphic, if so the returned g satisfies F2g=F1}
 if #F1 ne #F2 /*or not Compatible(F1[1],F2[1])*/ then
  return false,_;
 end if;
 b,g:=IsUIsomorphic(F1[1],F2[1]);
 if not b then 
  return false,_;
 end if;
 H:=BaseRing(GeneratingMatrix(F1[1]));
 F1Stabs:=[UStab(F1[1])];
 for i in [2..#F1] do
  b:=false;
  for x in &meet F1Stabs do
   gg:=g*RegularToQuat(x,H); 
   if F2[i]*gg eq F1[i] then
    b:=true;
    g:=gg;
    break x;
   end if;
  end for;
  if not b then 
   return b,_;
  end if;
  if i ne #F1 then
   Append(~F1Stabs,UStab(F1[i]));
  end if;
 end for;
 return true,g;
end intrinsic;

intrinsic Facets(F::Tup)->List
 {Takes the tuple F of length n an returns all n-1 subtuples}
 res:=[**];
 for i in [1..#F] do
  Append(~res,<F[j]: j in [1..#F]|j ne i>);
 end for;
 return res;
end intrinsic;

//Computing the combinatorial structure:

intrinsic ComputePBuilding(H::AlgQuat,P::RngOrdIdl,m::RngIntElt,File::MonStgElt)
 {Computes the combinatorial structure of the building of U_m(H) at the split prime P and prints it to file}
 if m ne 2 then
  error "Not implemented for this dimension yet.";
 end if;
 V:=RSpace(H,m);
 B:=MatrixRing(H,m)!1;
 L:=HermitianLattice(B);
 O:=DefiningOrder(L);
 DH:=Divisors(Discriminant(H));
 NP:=Norm(P);
 if P in DH then
  error "Not split at this prime";
 end if;

 //Start by computing the first genus of hyperspecial points
 _,splitting,emb:=pMatrixRing(O,P);
 KP:=Codomain(emb);
 LP:=UToSpLat(L,splitting); 
 KR:=CosetRepresentatives(P,m,"0");
 ML:=MassSP(L);
 V1:=[<<L>,MatrixRing(Codomain(emb),2*m)!1>];
 V1Stabs:=[UStab(L)];
 ml:=&+[1/#S: S in V1Stabs];
 V1complete:=ml eq ML;
 ToDo:=V1;
 while #ToDo gt 0 do
  M:=ToDo[1];
  LM:=M[1];
  gM:=M[2];
  Exclude(~ToDo,M);
  for j in [1..#KR] do
   kr:=KR[j];
   NL:=<ConstructNeighbour(LM[1],gM^-1*EmbedMatrix(kr,emb)*gM,P,splitting)>;
   found:=false;
    for i in [1..#V1] do
       if IsUIsomorphic(NL,V1[i][1]) then
        found:=true;
        break i;
       end if;
    end for;
   if not found then
    Append(~V1,<NL,EmbedMatrix(KR[j],emb)*gM>);
    Append(~ToDo,<NL,EmbedMatrix(KR[j],emb)*gM>);
    Append(~V1Stabs,UStab(NL));
    V1complete:=&+[1/#x: x in V1Stabs] eq ML;
    if V1complete then ToDo:=[]; break j; end if;
   end if; 
  end for;
 end while;
 //Now V1 contains a system of representatives of the first genus of hyperspecial points.

 // Next we construct representatives for the chambers by acting with the stabilizers of hyperspecial points. Afterwards we construct the remaining genera as subsets of the chambers.
 p:=UniformizingElement(KP);
 BBP2:=DiagonalMatrix(&cat[[KP!p,1]: i in [1..2-1]] cat [1: i in [1..2*m-2*(2-1)]]);
 BBP3:=DiagonalMatrix(&cat[[KP!p,1]: i in [1..3-1]] cat [1: i in [1..2*m-2*(3-1)]]);
 L2:=ConstructNeighbour(L,BBP2,P,splitting);
 L3:=ConstructNeighbour(L,BBP3,P,splitting);
 C:=[<<L,L2,L3>,V1[1][2]>]; //One representative of the chambers (yields an Iwahori subgroup).
 MC:=(NP^4-1)*(NP^2-1)/((NP-1)^2)*ML;    //The mass of the genus.

 KR:=IntertwiningCosetRepresentatives(P,m,{1},{1,2,3});
 CStabs:=[UStab(C[1][1])];
 Ccomplete:=&+[1/#S: S in CStabs] eq MC;
 ToDo:=V1;
 while #ToDo gt 0 do
  M:=ToDo[1];
  gM:=M[2];
  Exclude(~ToDo,M);
  for j in [1..#KR] do
   kr:=KR[j];
   NL:=<ConstructNeighbour(x,EmbedMatrix(kr,emb)*gM,P,splitting): x in C[1][1]>;
   found:=false;
    for i in [1..#C] do
       if IsUIsomorphic(NL,C[i][1]) then
        found:=true;
        break i;
       end if;
    end for;
   if not found then
    Append(~C,<NL,EmbedMatrix(KR[j],emb)*gM>);
    Append(~CStabs,UStab(NL));
    Ccomplete:=&+[1/#x: x in CStabs] eq MC;
    print "New Chamber found, mass left: ", MC-&+[1/#S: S in CStabs];
    if Ccomplete then ToDo:=[]; break j; end if;
   end if; 
  end for;
 end while;

 //Now we construct the remaining genus representatives by taking subsets of chambers: THIS IS SO FUCKING STUPID, REPAIR AT SOME POINT
 V2pot:=[<<x[1][2]>,x[2]>: x in C];
 V3pot:=[<<x[1][3]>,x[2]>: x in C];
 E12pot:=[<<x[1][1],x[1][2]>,x[2]>: x in C];
 E13pot:=[<<x[1][1],x[1][3]>,x[2]>: x in C];
 E23pot:=[<<x[1][2],x[1][3]>,x[2]>: x in C];

 V2mass:=MassSP(V2pot[1][1][1]);
 V3mass:=MassSP(V3pot[1][1][1]);

 Emass:=MC/(NP+1);

 V2:=[];
 for x in V2pot do
  found:=false;
  for y in V2 do
   if IsUIsomorphic(x[1],y[1]) then
    found:=true;
    break y;
   end if;
  end for;
  if not found then 
   Append(~V2,x);
  end if;
 end for;

 require &+[1/#UStab(x[1]): x in V2] eq V2mass: "Mass formula does not add up for vertices of label 2. This should not have happened";

 V3:=[];
 for x in V3pot do
  found:=false;
  for y in V3 do
   if IsUIsomorphic(x[1],y[1]) then
    found:=true;
    break y;
   end if;
  end for;
  if not found then 
   Append(~V3,x);
  end if;
 end for;

 require &+[1/#UStab(x[1]): x in V3] eq V3mass: "Mass formula does not add up for vertices of label 3. This should not have happened";

 E12:=[];
 for x in E12pot do
  found:=false;
  for y in E12 do
   if IsUIsomorphic(x[1],y[1]) then
    found:=true;
    break y;
   end if;
  end for;
  if not found then 
   Append(~E12,x);
  end if;
 end for;

 require &+[1/#UStab(x[1]): x in E12] eq Emass: "Mass formula does not add up for edges of label 12. This should not have happened";

 E13:=[];
 for x in E13pot do
  found:=false;
  for y in E13 do
   if IsUIsomorphic(x[1],y[1]) then
    found:=true;
    break y;
   end if;
  end for;
  if not found then 
   Append(~E13,x);
  end if;
 end for;

 require &+[1/#UStab(x[1]): x in E13] eq Emass: "Mass formula does not add up for edges of label 13. This should not have happened";

 E23:=[];
 for x in E23pot do
  found:=false;
  for y in E23 do
   if IsUIsomorphic(x[1],y[1]) then
    found:=true;
    break y;
   end if;
  end for;
  if not found then 
   Append(~E23,x);
  end if;
 end for;

 require &+[1/#UStab(x[1]): x in E23] eq Emass: "Mass formula does not add up for edges of label 23. This should not have happened";

 //Now we compute the combinatorial structure.
 Cells:=[*V1 cat V2 cat V3,E12 cat E13 cat E23,C*];
 
 Dims:=[#x: x in Cells];

 Stabilizers:=[[Setseq(Generators(UStab(L[1]))):L in F]:F in Cells];

 Boundary:=[**];
 for i in [2..#Cells] do
  tmpi:=[**];
  for j in [1..#Cells[i]] do
   tmpj:=[**];
   facetsj:=Facets(Cells[i][j][1]);
   for f in facetsj do
    for k in [1..#Cells[i-1]] do
     b,g:=IsUIsomorphic(Cells[i-1][k][1],f);
     if b then
      Append(~tmpj,[*k,QuatToRegular(g)*]);
      break k;
     end if;
    end for;
   end for;
   Append(~tmpi,tmpj);
  end for; 
  Append(~Boundary,tmpi);
 end for;

 Elts:=[];
 for i in [1..#Cells] do
  for j in [1..#Cells[i]] do
   for g in Stabilizers[i][j] do
    if not g in Elts then 
     Append(~Elts,g);
    end if;
   end for;
  end for;
 end for;

 for i in [2..#Cells] do
  for j in [1..#Cells[i]] do
   for k in [1..#Boundary[i-1][j]] do
    x:=Boundary[i-1][j][k];
    if not x[2] in Elts then
     Append(~Elts,x[2]);
    end if;
    Boundary[i-1][j][k]:=[*x[1],Position(Elts,x[2])*];
   end for;
  end for;
 end for;
 
 Gens:=Elts;

 str:="";
 str cat:= DimensionsToGapString(Dims);
 str cat:= ElementsToGapString(Elts);
 str cat:= StabilizersToGapString(Stabilizers);
 str cat:= BoundaryComponentsToGapString(Boundary);
 Write(File,str);

 
 

end intrinsic;
