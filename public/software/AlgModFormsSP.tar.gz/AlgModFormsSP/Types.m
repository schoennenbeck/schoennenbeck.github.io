
declare type HermLat;
declare attributes HermLat: Generators,RegularLattice,UStab,AllForms,Order,HermSpace;

declare attributes AlgQuat: RegularRepresentation,MaxOrd;

declare attributes AlgAssVOrd: Gens;

declare attributes ModRng: RegularForm,KBasis;

declare attributes AlgMat: CentralizerBasis;

declare attributes FldPad: Embedding;

