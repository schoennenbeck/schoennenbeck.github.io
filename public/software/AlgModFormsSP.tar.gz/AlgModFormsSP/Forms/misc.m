//freeze;

declare type ProcPL;

declare attributes ProcPL:
  a,
  v,
  dim,
  depth;

declare attributes RngOrd: 
  SquareClasses;

intrinsic Print(PL::ProcPL)
{internal}
  printf "A projective line process for %m", Parent(PL`v);
end intrinsic;

intrinsic ProjectiveLineProcess(V::ModTupFld[FldFin]) -> ProcPL
{Creates a projective line process for V}
  PL:= New(ProcPL);
  PL`a:= PrimitiveElement(BaseField(V));
  PL`v:= V ! 0;
  PL`dim:= Dimension(V);
  PL`depth:= PL`dim+1;
  return PL;
end intrinsic;

intrinsic ProjectiveLineProcess(k::FldFin, n::RngIntElt) -> ProcPL
{Creates a projective line process for k^n}
  requirege n, 1;
  return ProjectiveLineProcess(VectorSpace(k, n));
end intrinsic;

intrinsic '#'(PL::ProcPL) -> RngIntElt
{The number of lines in PL}
  q:= #Parent(PL`a);
  return (q^PL`dim-1) div (q-1);
end intrinsic;

intrinsic Next(PL::ProcPL) -> ModTupFldElt
{The next element in the process. Returns the zero vector if no more elements left}
  if PL`depth ne 0 then
    i:= PL`dim;
    while true do
      if i eq PL`depth then
        PL`v[i]:= 0; i -:= 1;
      elif i lt PL`depth then
        PL`depth:= i;
	if i ge 1 then PL`v[i]:= 1; end if;
	break;
      elif PL`v[i] eq 0 then PL`v[i]:= 1; break;
      else
        PL`v[i] *:= PL`a;
	if PL`v[i] eq 1 then PL`v[i]:= 0; i -:= 1; else break; end if;
      end if;
    end while;
  end if;
  return PL`v;
end intrinsic;

// Computing with K_p^* / (K_p^*)^2.

// Helper function to ensure x is a unit.
function forceunit(x)
  error if x eq 0, "element must be non-zero";
  return x;
end function;

// Helper function to find y such that xy^2 is integral and Valuation(xy^2, p) = 0
function SquareRepNice(x, p, piinv)
  x *:= Denominator(x)^2;
  v:= Valuation(x, p);
  assert v ge 0 and IsEven(v);
  if v ne 0 then x *:= piinv^v; end if;
  return Order(p) ! x;
end function;

// todo: Abelian group would be better....
intrinsic LocalMultiplicativeGroupModSquares(p::RngOrdIdl) -> ModFld, Map
{Given a prime ideal over some number field K, this returns a vectorspace
 over GF(2) isomorphic to K_p^/(K_p^*)^2 and a map representing the isomorphism}
  require IsPrime(p): "The ideal must be prime";
  R:= Order(p);
  K:= NumberField(R);
  pi:= PrimitiveElement(p);
  if Minimum(p) ne 2 then
    k, h:= ResidueClassField(p);
    e:= Nonsquare(k) @@ h;
    V:= VectorSpace(GF(2), 2);
    m:= map< V -> K |
      x :-> (x[1] eq 0 select 1 else e) * (x[2] eq 0 select 1 else pi),
      y :-> [ IsSquare((y/pi^v) @ h) select 0 else 1, v] where v:= Valuation(forceunit(y), p)
    >;
    return V, m;
  else
    if not assigned R`SquareClasses then R`SquareClasses:= AssociativeArray(); end if;
    ok, m:= IsDefined(R`SquareClasses, p);
    if not ok then
      e:= RamificationIndex(p);
      dim:= Valuation(Norm(p), 2)*e+2;
      piinv:= WeakApproximation([p], [-1]);
      V:= VectorSpace(GF(2), dim);
      I:= p^(2*e+1);
      Q, h:= quo< R | I >;
      U, g:= UnitGroup(Q);
      M, i:= quo< U | 2*U >;
      assert #M eq 2^(dim-1);
      m:= map< V -> K | x :-> ((M ! ChangeUniverse(Eltseq(x)[1..dim-1], Integers())) @@ i @ g @@ h) * (x[dim] eq 0 select 1 else pi),
                        y :-> Append(Eltseq(SquareRepNice(y * pi^v, p, piinv) @@ g @ i), v) where v:= Valuation(y, p) mod 2 >;
      R`SquareClasses[p]:= m;
    end if;
    return Domain(m), m;
  end if;
end intrinsic;

intrinsic UnitSquareClassReps(p::RngOrdIdl) -> []
{Given a prime ideal of some number ring return a system
 of representatives of the units R_p^* modulo squares}
  V, h:= LocalMultiplicativeGroupModSquares(p);
  U:= sub< V | [V.i: i in [1..Dimension(V)-1]] >;
  return [ u @ h : u in U ];
end intrinsic;

// End of unit group computations


// The even HilbertSymbol code

// We first start with our implementation of Alg. 6.2 -- 6.5 of
// John Voight, Characterizing quaternion rings over an arbitrary base, J. Reine Angew. Math. 657 (2011), 113-134.
function SolveCongruence(a,b,p)
  //assert Valuation(a,p) eq 0;
  //assert Valuation(b,p) eq 1;
  pi:= PrimitiveElement(p);
  k, h:= ResidueClassField(p);
  y:= 1/(SquareRoot(a @ h) @@ h); z:= 0;
  ee:= 2*RamificationIndex(p);
  told:= -1;
  while true do
    N:= 1 - a*y^2 - b*z^2;
    t:= Valuation(N, p); assert t gt told; told:= t;
    if t ge ee then return y,z; end if;
    w:= pi^(t div 2);
    if IsEven(t) then
      y +:= SquareRoot((N/(a*w^2)) @ h) @@ h * w;
    else
      z +:= SquareRoot((N/(b*w^2)) @ h) @@ h * w;
    end if;
  end while;
end function;

// Decide if a*x^2=1 mod p^e
// This is a variant of O'Meara ???. The code assumes that 0 <= e <= 2*RamIdx(p)
function CanLiftSquare(a,p,e)
  assert Valuation(a,p) eq 0;
  if Valuation(a-1, p) ge e then return true, Order(p) ! 1, e; end if;
  aold:= a;
  pi:= PrimitiveElement(p);
  k, h:= ResidueClassField(p);
  x:= SquareRoot( (a @ h)^-1 ) @@ h;
  a *:= x^2;
  t:= Valuation(a-1, p);
  while t lt e and IsEven(t) do
    s:= SquareRoot(h((a-1)/pi^t));
    s:= 1+(s@@h)*pi^(t div 2);
    a /:= s^2;
    x := x/s;
    tt:= Valuation(a-1, p);
    assert tt gt t;
    t:= tt;
  end while;
  t:= Min(t,e);
  assert Valuation(aold*x^2-1, p) ge t;
  return t eq e, x, t;
end function;

function SolveCongruence2(a,b,p)
  if Valuation(b, p) eq 1 then 
    y,z:= SolveCongruence(a,b,p);
    return y,z,0;
  end if;
  
  e:= RamificationIndex(p);
  pi:= PrimitiveElement(p);
  oka, a0, t:= CanLiftSquare(a, p, e);
  if oka then
    okb, b0, t:= CanLiftSquare(b, p, e);
    if okb then return a0, b0, a0*b0; end if;
    bt:= (b-(1/b0)^2) /pi^t;
    y, z:= SolveCongruence(b, -pi*bt/a, p);
    w:= pi^(t div 2);
    return w*b0/z, b0, y*w*b0/z;
  else
    at:= (a-(1/a0)^2) /pi^t;
    y, z:= SolveCongruence(a, -pi*at/b, p);
    w:= pi^(t div 2);
    return a0, w*a0/z, y*w*a0/z;
  end if;
end function;

normalize:= function(a, p, pi)
  vala:= Valuation(a, p);
  n:= vala div 2;
  if n ne 0 then a /:= pi^(2*n); vala -:= 2*n; end if;
  assert Valuation(a, p) eq vala and vala in {0,1};
  return a, vala;
end function;

//function MyEvenHilbertSymbol(a,b,p)
intrinsic MyEvenHilbertSymbol(a::FldElt,b::FldElt,p::RngOrdIdl) -> RngIntElt
{}
/*
  ok, n:= IsIntegral(a); if not ok then a *:= n^2; end if;
  ok, n:= IsIntegral(b); if not ok then b *:= n^2; end if;
  piinv:= WeakApproximation([p], [-1]);
  vala:= Valuation(a, p);
  if vala gt 1 then a *:= piinv^(2*(vala div 2)); end if;
  valb:= Valuation(b, p);
  if valb gt 1 then b *:= piinv^(2*(valb div 2)); end if;
*/
  pi:= PrimitiveElement(p);
  a, vala:= normalize(a, p, pi);
  b, valb:= normalize(b, p, pi);
  if vala eq 1 then
    if valb eq 1 then
      a:= (-a*b) / pi^2;
    else
      x:= a; a:= b; b:= x;
    end if;
  end if;

  y,z,w:= SolveCongruence2(a,b,p);
  nrm:= 1-a*y^2-b*z^2+a*b*w^2;
  assert Valuation(nrm, p) ge 2*RamificationIndex(p);
  k,h:= ResidueClassField(p);
  if not IsIrreducible(Polynomial([k| (nrm/4)@h,-1,1])) then /*assert HilbertSymbol(a,b,p) eq 1;*/ return 1; end if;
  res:= IsEven(Valuation((b*z)^2*a + (a*y)^2*b, p)) select 1 else -1;
  //assert res eq HilbertSymbol(a,b,p);
  return res;
end intrinsic;
//end function;


AddAttribute(Fld, "HSCache");

function HS(x, y, p, r : cache:= false)
  R := Order(p);
  K := NumberField(R);
  if IsEven(r) or x eq 1 or y eq 1 then return 1; end if;

  if not assigned K`HSCache then
    D2:= Decomposition(R, 2);
    K`HSCache:= < {@ d[1]: d in D2 @}, [WeakApproximation([d[1]], [-1]) : d in D2] , [ h where _, h:= quo< R | d[1]^(1+2*d[2]) > : d in D2], [ AssociativeArray(PowerSet(K))^^#D2 ] >;
  end if;

  i:= Index(K`HSCache[1], p); assert i ne 0;
  x:= K ! x; y:= K ! y;

  S:= {x, y};
  ok, res:= IsDefined(K`HSCache[4, i], S);
  if ok then return res; end if;

  if cache then         // we need to get the result now.
    res:= HilbertSymbol(x, y, p);
    K`HSCache[4, i, S]:= res;
    return res;
  end if;

  // Reduce x, y and then use the cache.
  pi:= K`HSCache[2,i];
  h := K`HSCache[3,i];
  ok, n:= IsIntegral(x); if not ok then x *:= n^2; end if;
  ok, n:= IsIntegral(y); if not ok then y *:= n^2; end if;
  valx:= Valuation(x, p); valy:= Valuation(y, p);
  u:= x*pi^valx; v:= y*pi^valy;
  uu:= (u @ h) @@ h; vv:= (v @ h) @@ h;
  // This computes up to 3 symbols, but in the long run, chances are, we already know all results, since uu, vv, pi are unique!
  
  res:= $$(uu, vv, p, 1         : cache);
  if IsOdd(valx) then
    if IsOdd(valy) then
      res *:= $$( ((uu*vv) @ h) @@ h, pi, p, 1 : cache) * $$(pi, pi, p, 1 : cache);
    else
      res *:= $$(vv, pi, p, 1 : cache);
    end if;
  elif IsOdd(valy) then
    res *:= $$(uu, pi, p, 1 : cache);
  end if;
  //assert res eq HilbertSymbol(x, y, p);
  return res; 
  res:= $$(uu, vv, p, 1         : cache) *
        $$(pi, vv, p, valx      : cache) *
        $$(uu, pi, p, valy      : cache) *
        $$(pi, pi, p, valx*valy : cache);
  //assert res eq HilbertSymbol(x, y, p);
  return res;
end function;

intrinsic MyHilbertSymbol(a::FldAlgElt, b::FldAlgElt, p::RngOrdIdl) -> RngIntElt
{The Hilbert symbol of a and b at p}
  if IsOne(a) or IsOne(b) then return 1; end if;
  require not IsZero(a) and not IsZero(b): "The elements must be non-zero";
  require IsPrime(p): "The ideal must be prime";
//  return Minimum(p) ne 2 select HilbertSymbol(a,b,p) else HS(a,b,p,1);
  return Minimum(p) ne 2 select HilbertSymbol(a,b,p) else MyEvenHilbertSymbol(a,b,p);
end intrinsic;


// Working with ideal class groups
intrinsic PrimeIdealGenerators(I :: RngOrdIdl, S::[] : CoprimeTo:= 0) -> []
{Returns prime ideals that generate the ray class group of I and the infinite places in S}
  if not IsEmpty(S) and Type(Universe(S)) eq PlcNum then
    T:= [];
    for s in S do 
      ok, i:= IsInfinite(s); require ok: "The places must be infinite";
      Append(~T, i);
    end for;
    S:= Sort(T);
  end if;
  C, h:= RayClassGroup(I, S);
  R:= Order(I);
  L:= [ PowerIdeal(R) | ];
  U:= sub< C | >; 
  p:= 1; i:= 1; D:= []; 
  while #U ne #C do
    if i ge #D then p:= NextPrime(p); D:= Decomposition(R, p); i:= 1; end if;
    if (CoprimeTo cmpeq 0 or Valuation( CoprimeTo, D[i,1] ) eq 0) and IsOne(I+D[i,1]) then
      g:= D[i,1] @@ h;
      if g notin U then Append(~L, D[i,1]); U:= sub< C | U, g >; end if;
    end if;
    i +:= 1;
  end while;
  return L; 
end intrinsic;

intrinsic PrimeIdealGenerators(I :: RngOrdIdl : CoprimeTo:= 0) -> []
{"}; //"
  return PrimeIdealGenerators(I, []: CoprimeTo:= CoprimeTo);
end intrinsic;

intrinsic PrimeIdealGenerators(R :: RngOrd: CoprimeTo:= 0) -> []
{Returns prime ideals that generate the ideal class group of R}
  return PrimeIdealGenerators(1*R, [] : CoprimeTo:= CoprimeTo);
end intrinsic;

// Evaluating Dedekind zeta functions exactly.
function ExtensionToHeckeCharacter(E)
  assert Degree(E) eq 2;
  K:= BaseField(E);
//  if not IsAbsoluteField(K) then K:= AbsoluteField(K); end if;
  RE:= Integers(E);

  S:= [];
  for i in RealPlaces(K) do
    if #Decomposition(E, i) ne 2 then 
      ok, idx:= IsInfinite(i); assert ok;
      Append(~S, idx);
    end if;
  end for;
  S:= Sort(S);

//  S:= [1..Degree(K)];
  DE:= Discriminant(RE);
  P:= PrimeIdealGenerators(DE, S);
  T:= < <p, IsSplit(p, RE) select 1 else -1> : p in P >; 
  h:= HeckeCharacter(DE, S, T);
  assert IsPrimitive(h);
  return h;
end function;

function myEval(K, z, Relative)
  if IsOdd(z) then
    k:= 1-z;
    if Type(K) eq FldRat then
      return BernoulliNumber(k)/-k;
    elif AbsoluteDegree(K) eq 2 then
      d:= Discriminant(Integers(K));
      if d gt 1 then
        return BernoulliNumber(k) * BernoulliNumber(k, KroneckerCharacter(d, Rationals())) / k^2;
      end if;
    end if;
  end if;

  if Relative then
    H:= ExtensionToHeckeCharacter(K);
    L:= LSeries(H);
//    F:= BaseField(K);
//    K:= OptimizedRepresentation(AbsoluteField(K));
//    L:= LSeries(K : Method:= Degree(F) ge 5 select "Direct" else "Default") / LSeries(F);
  else
    L:= LSeries(K);
  end if;

  i:= 0;
  repeat
    if i ge 1 then 
      LSetPrecision(L, 40 + i*20); 
      "increasing precision", i; 
    end if;
    x:= Evaluate(L, z);
    if Type(x) eq FldComElt and Im(x) le 10^-20 then x:= Re(x); end if;
    X:= Type(x) eq FldReElt select { BestApproximation(x, 10^i) : i in [12, 14, 16, 18] } else [];
    i +:= 1;
  until #X eq 1;
  X:= Rep(X);

//  if Relative then
//    assert Abs(Real(Evaluate(LSeries(H), z)) - X) le 10^-10;
//  end if;
  return X;
end function;

intrinsic DedekindZetaExact(K::FldAlg, z::RngIntElt: Relative:= false) -> FldRatElt
{Evaluates the Dedekind zeta function of K at the negative integer z}
  require (Relative and z eq 0) or z lt 0 : "The argument must be a negative integer";
  return myEval(K, z, Relative);
end intrinsic;

intrinsic DedekindZetaExact(K::FldRat, z::RngIntElt: Relative:= false) -> FldRatElt
{"} //"
  require (Relative and z eq 0) or z lt 0 : "The argument must be a negative integer";
  return myEval(K, z, Relative);
end intrinsic;
