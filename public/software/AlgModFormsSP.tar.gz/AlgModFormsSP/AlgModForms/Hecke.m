//Working in the split version of the symplectic group where the form is diag(J,J,J) with J=[[0,1],[-1,0]].
//THE FIRST FEW FUNCTIONS WILL ONLY BE USED INTERNALLY

Z:=Integers();
Q:=Rationals();
IO:=recformat<T12,T21,Peterson1,Peterson2,Genus1,Genus2,FormSpaceBasis1,FormSpaceBasis2>; //A format for returning intertwining operators

GS:=recformat<Discriminant,Dimension,Labels>; //A genus symbol format for describing genera of maximal integral forms of SP2n


//Some internal functions for working with a split SP2m
//The simple roots (with respect to the diagonal torus) and the highest root:


alpha:=function(m,i,d)
 if i gt 0 and i lt m then 
  return d[2*i-1][2*i-1]^-1*d[2*i+1][2*i+1];
 end if;
 if i eq m then
  return d[2*m-1][2*m-1]^-2;
 end if;
 if i eq 0 then
  return d[1][1]^-2;
 end if;
 error "This simple root does not exist.";
end function;


//The coroots:

alphawedge:=function(m,i,x)
 if i gt 0 and i lt m then
  return DiagonalMatrix([x-x+1: j in [1..2*(i-1)]] cat [x^-1,x,x,x^-1] cat [x-x+1: j in [1..2*m-2*i-2]]);
 end if;
 if i eq m then
  return DiagonalMatrix([x-x+1: j in [1..2*m-2]] cat [x^-1,x]);
 end if;
 if i eq 0 then
  return DiagonalMatrix([x^-1,x] cat [x-x+1: j in [1..2*m-2]]);
 end if;
 error "This coroot does not exist.";
end function;
 


//The most important root vectors:

//First for the three simple roots; the Liealgebra is given by a*J+J*a^T=0 and the torus acts via t^-1at.
XA:=function(m,i)
 if i lt 0 or i gt m then
  error "This root vector does not exist";
 end if;
 x:=MatrixRing(Z,2*m)!0;
 if i gt 0 and i lt m then
  x[2*i-1][2*i+1]:=1;
  x[2*i+2][2*i]:=-1;
 end if;
 if i eq m then
  x[2*m-1][2*m]:=1;
 end if;
 if i eq 0 then //This is the root vector corresponding to the NEGATIVE of the highest root
  x[2][1]:=1;
 end if;
 return x;
end function;


//The symplectic form we use:
J:=MatrixRing(Q,2)![0,1,-1,0];
JJ:=DiagonalJoin([J,J,J]);

//The Weyl-group

SSP:=function(m,i) //The i-th involutive generator of the Weylgroup of SP_2m
 S2m:=SymmetricGroup(2*m);
 if i lt 1 or i gt m then
  error "This generators does not exist";
 end if;
 if i lt m then
  return PermutationMatrix(Z,S2m!(2*i-1,2*i+1)(2*i,2*i+2));
 end if;
 if i eq m then
  s:=PermutationMatrix(Z,S2m!(2*m-1,2*m));
  s[2*m][2*m-1]:=-1;
  return s;
 end if;
end function;

S0SP:=function(m,P) //The additional involutive generator for the affine Weylgroup
 pi:=UniformizingElement(P);
 OK:=Order(P);
 K:=FieldOfFractions(OK);
 return DiagonalJoin(MatrixRing(K,2)![[0,-1/pi],[pi,0]],MatrixRing(K,2*m-2)!1);
end function;


//Some functions do work with the Lie-algebra
matexp:=function(M);
 b,d:=IsNilpotent(M);
 if not b then return "MIST"; end if;
 return &+[1/(Factorial(k))*M^k: k in [0..d]];
end function;

LieKlammer:=function(a,b)
 return a*b-b*a;
end function;

//CosetRepresentatives

intrinsic CosetRepresentatives(P::RngOrdIdl,m::RngIntElt,w::MonStgElt)->SeqEnum
 {The representatives for the right-coset decomposition of w, with respect to the maximal compact subgroup specified by w[1]}
 //We follow the formula from Lansky01
 OK:=Order(P);
 K:=FieldOfFractions(OK);
 p:=UniformizingElement(P);
 kP:=quo<OK|P>;
 kPR:=[OK!x: x in kP];
 if not OK!0 in kPR then
  pos:=Position([y in P: y in kPR],true);
  kPR[pos]:=OK!0;
 end if;
 Rep:=[K!x: x in kPR]; //Rep is now a system of representatives of OK/p containing zero
 y:=function(j,r) //Just shorthand for later use. In Lanksy this function is called g_alpha(r)
  if j in [1..m] then
   return SSP(m,j)*matexp(r*XA(m,j));
  end if;
  if j eq 0 then
   return S0SP(m,P)*matexp(p*r*XA(m,0));
  end if;
  error "Some implementation error occured.";
 end function;

 Cm:=m gt 1 select CoxeterGroup("C" cat Sprint(m) cat "~") else CoxeterGroup("A" cat Sprint(m) cat "~");
 ww:=[StringToInteger(w[i]): i in [1..#w]];
 ww:=[x eq 0 select m+1 else x: x in ww];
 www:=Cm!ww;
 require Length(www) eq #w: "Please enter a reduced expression";
 i:=ww[1];
 Pi,embPi:=StandardParabolicSubgroup(Cm,{x: x in [1..m+1] | x ne i});//We need the representatives of Pi module Pi cap ^wPi (see Lanskys article)
 Img:=[embPi(Pi.j): j in [1..Ngens(Pi)]];
 Pcapgen:={Cm.j: j in [1..m+1] | j ne i} meet {www^-1*Cm.j*www: j in [1..m+1] | j ne i};
 PiPerm,embPiPerm:=CoxeterGroup(GrpPermCox,Pi);
 Pcap:=StandardParabolicSubgroup(PiPerm,{Position(Img,x):x in Pcapgen});
 TT:=Transversal(PiPerm,Pcap);
 TT:=[embPi(x @@ embPiPerm): x in TT];
 TTseq:=[Eltseq(x): x in TT];
 function SeqToReps(v) //v is an eltseq say [1,2]. this function then return all y(1,r)*y(2,rr) with r and rr in Rep
  v:=[x eq m+1 select 0 else x: x in v];
  res:=[y(v[1],r): r in Rep];
  for k in [2..#v] do
   res:=[x*y(v[k],r): x in res, r in Rep];
  end for;
  return res;
 end function;
 res:=[SeqToReps(ww)];
 for k in [2..#TTseq] do
  v:=TTseq[k];
  pos:=Position(TTseq,Remove(v,#v)); //We could just take the product over all of v but this way we use way less multiplications.
  Append(~res,[x*xx: x in res[pos],xx in SeqToReps([v[#v]])]);
 end for;
 return &cat res;
end intrinsic;


intrinsic CosetRepresentatives(P::RngOrdIdl,m::RngIntElt,i::RngIntElt)->SeqEnum
 {The representatives for the rightcoset decomposition of the i-th generator of the heckealgebra of SP2m at the hyperspecial place P}
 //We make use of the function above and simply write down a reduced expression for the ith generator (see section 5.2.2) 
 require i in [1..m]: "This generator does not exist in this dimension.";
 s:=[];
 for j in [1..i] do
  for k in [0..i-j] do
   Append(~s,k);
  end for;
 end for;
return CosetRepresentatives(P,m,s,{0});
end intrinsic;

intrinsic CosetRepresentatives(P::RngOrdIdl,m::RngIntElt,w::SeqEnum,Para::SetEnum)->SeqEnum
 {The representatives for the right-coset decomposition of w, with respect to the parahoric subgroup specified by Para (If we wanted the standard hyperspecial subgroup we would take Para=(1)}
 //We follow the formula from Lansky01
 OK:=Order(P);
 K:=FieldOfFractions(OK);
 p:=UniformizingElement(P);
 kP:=quo<OK|P>;
 kPR:=[OK!x: x in kP];
 if not OK!0 in kPR then
  pos:=Position([y in P: y in kPR],true);
  kPR[pos]:=OK!0;
 end if;
 Rep:=[K!x: x in kPR]; //Rep is now a system of representatives of OK/p containing zero
 y:=function(j,r) //Just shorthand for later use. In Lanksy this function is called g_alpha(r)
  if j in [1..m] then
   return SSP(m,j)*matexp(r*XA(m,j));
  end if;
  if j eq 0 then
   return S0SP(m,P)*matexp(p*r*XA(m,0));
  end if;
  error "Some implementation error occured.";
 end function;

 Cm:=CoxeterGroup("C" cat Sprint(m) cat "~");
 ww:=[x eq 0 select m+1 else x: x in w];
 Para:={x eq 0 select m+1 else x: x in Para};
 www:=Cm!ww;
 require Length(www) eq #w: "Please enter a reduced expression";
 if Para ne {1..m+1} then
  Pi,embPi:=StandardParabolicSubgroup(Cm,{x: x in [1..m+1] | not x in Para});//We need the representatives of Pi module Pi cap ^wPi (see Lanskys article)
  Img:=[embPi(Pi.j): j in [1..Ngens(Pi)]];
  Pcapgen:={Cm.j: j in [1..m+1] | not j in Para} meet {www^-1*Cm.j*www: j in [1..m+1] | not j in Para};
  PiPerm,embPiPerm:=CoxeterGroup(GrpPermCox,Pi);
  Pcap:=StandardParabolicSubgroup(PiPerm,{Position(Img,x):x in Pcapgen});
  TT:=Transversal(PiPerm,Pcap);
  TT:=[embPi(x @@ embPiPerm): x in TT];
  TTseq:=[Eltseq(x): x in TT];
 else
  TTseq:=[Eltseq(www)];
 end if;
 function SeqToReps(v) //v is an eltseq say [1,2]. this function then return all y(1,r)*y(2,rr) with r and rr in Rep
  v:=[x eq m+1 select 0 else x: x in v];
  res:=[y(v[1],r): r in Rep];
  for k in [2..#v] do
   res:=[x*y(v[k],r): x in res, r in Rep];
  end for;
  return res;
 end function;
 res:=[SeqToReps(ww)];
 for k in [2..#TTseq] do
  v:=TTseq[k];
  pos:=Position(TTseq,Remove(v,#v)); //We could just take the product over all of v but this way we use way less multiplications.
  Append(~res,[x*xx: x in res[pos],xx in SeqToReps([v[#v]])]);
 end for;
 return &cat res;
end intrinsic;


intrinsic IntertwiningCosetRepresentatives(P::RngOrdIdl,m::RngIntElt,gen1::RngIntElt,gen2::RngIntElt)->SeqEnum
 {Coset representatives of the stabilizer of gen2 in the stabilizer of gen1}
 require {gen1,gen2} subset {1..m+1}: "These genera do not exist in this dimension";
 OK:=Order(P);
 K:=FieldOfFractions(OK);
 p:=UniformizingElement(P);
 kP:=quo<OK|P>;
 kPR:=[OK!x: x in kP];
 if not OK!0 in kPR then
  pos:=Position([y in P: y in kPR],true);
  kPR[pos]:=OK!0;
 end if;
 Rep:=[K!x: x in kPR];
 //For easier access:
 y:=function(j,r)
  if j in [1..m] then
   return SSP(m,j)*matexp(r*XA(m,j));
  end if;
  if j eq 0 then
   return S0SP(m,P)*matexp(p*r*XA(m,0));
  end if;
  error "Some implementation error occured.";
 end function;
 Cm:=CoxeterGroup("C" cat Sprint(m) cat "~");
 gen1:=gen1 eq 1 select m+1 else gen1-1; //We want gen1,gen2 to be given in the sense of the label function but we need to know to which group this corresponds
 gen2:=gen2 eq 1 select m+1 else gen2-1;

 P1,embP1:=StandardParabolicSubgroup(Cm,{x: x in [1..m+1] | x ne gen1 });
 Img:=[embP1(P1.j): j in [1..Ngens(P1)]];
 Pcapgen:={Cm.j: j in [1..m+1] | j ne gen1 and j ne gen2}; //Generators for the intersection of the two stabilizers
 P1Perm,embP1Perm:=CoxeterGroup(GrpPermCox,P1);
 Pcap:=StandardParabolicSubgroup(P1Perm,{Position(Img,x):x in Pcapgen});
 TT:=Transversal(P1Perm,Pcap);
 TT:=[embP1(x @@ embP1Perm): x in TT];
 TTseq:=[Eltseq(x): x in TT];
 

 RepsList:=[[MatrixRing(K,2*m)!1]];
 for k in [2..#TTseq] do
  v:=TTseq[k];
  pos:=Position(TTseq,Remove(v,#v));
  Append(~RepsList,[x*y(v[#v] eq m+1 select 0 else v[#v],r): x in RepsList[pos],r in Rep]);
 end for;
 return &cat RepsList;

end intrinsic;

intrinsic IntertwiningCosetRepresentatives(P::RngOrdIdl,m::RngIntElt,gen1::SetEnum,gen2::SetEnum)->SeqEnum
 {Coset representatives of the stabilizer of gen2 in the stabilizer of gen1 (same as above, but no need for maximality)}
 require gen1 join gen2 subset {1..m+1}: "These genera are not valid for this dimension";
 OK:=Order(P);
 K:=FieldOfFractions(OK);
 p:=UniformizingElement(P);
 kP:=quo<OK|P>;
 kPR:=[OK!x: x in kP];
 if not OK!0 in kPR then
  pos:=Position([y in P: y in kPR],true);
  kPR[pos]:=OK!0;
 end if;
 Rep:=[K!x: x in kPR];
 //For easier access:
 y:=function(j,r)
  if j in [1..m] then
   return SSP(m,j)*matexp(r*XA(m,j));
  end if;
  if j eq 0 then
   return S0SP(m,P)*matexp(p*r*XA(m,0));
  end if;
  error "Some implementation error occured.";
 end function;
 Cm:=CoxeterGroup("C" cat Sprint(m) cat "~");
 gen1:={x eq 1 select m+1 else x-1 : x in gen1}; //We want gen1,gen2 to be given in the sense of the label function but we need to know to which group this corresponds
 gen2:={x eq 1 select m+1 else x-1 : x in gen2};

 P1,embP1:=StandardParabolicSubgroup(Cm,{x: x in [1..m+1] | not x in gen1 });
 Img:=[embP1(P1.j): j in [1..Ngens(P1)]];
 Pcapgen:={Cm.j: j in [1..m+1] | not j in gen1 and not j in gen2}; //Generators for the intersection of the two stabilizers
 P1Perm,embP1Perm:=CoxeterGroup(GrpPermCox,P1);
 Pcap:=StandardParabolicSubgroup(P1Perm,{Position(Img,x):x in Pcapgen});
 TT:=Transversal(P1Perm,Pcap);
 TT:=[embP1(x @@ embP1Perm): x in TT];
 TTseq:=[Eltseq(x): x in TT];
 

 RepsList:=[[MatrixRing(K,2*m)!1]];
 for k in [2..#TTseq] do
  v:=TTseq[k];
  pos:=Position(TTseq,Remove(v,#v));
  Append(~RepsList,[x*y(v[#v] eq m+1 select 0 else v[#v],r): x in RepsList[pos],r in Rep]);
 end for;
 return &cat RepsList;

end intrinsic;




intrinsic Label(L::HermLat,P::RngOrdIdl)->RngIntElt
 {returns the type of the lattice L at P. This expects some goodwill on the part of the user}
 RL:=RegularLattice(L);
 DRL:=Dual(RL);
 if not RL subset DRL then 
  return 0;
 end if;
 
 ED:=ElementaryDivisors(Module(DRL),Module(RL));
 ED:=&cat[Factorization(x): x in ED];
 if #[i: i in [1..#ED]|ED[i][1] eq P  ] eq 0 then 
  return 1;
 end if;
 if not #[i: i in [1..#ED]|ED[i][1] eq P and ED[i][2] ne 1] eq 0 then
  return 0;
 end if;

 return #[i: i in [1..#ED]|ED[i][1] eq P and ED[i][2] eq 1] div 4 + 1;

end intrinsic;

intrinsic Label(F::Tup,P::RngOrdIdl)->RngIntElt
 {returns the type of the facet F at P. This expects some goodwill on the part of the user}
 return {Label(F[i],P): i in [1..#F]};
end intrinsic;

intrinsic MassSP(L::HermLat)->RngIntElt
 {Computes the mass of the genus of L via the formula 11.2 in "Group schemes and local densities". We assume that L is maximal.}
 RL:=RegularLattice(L);
 m:=Dimension(RL) div 4;
 H:=BaseRing(GeneratingMatrix(L));
 K:=AbsoluteField(BaseField(H));
 d:=Degree(K);
 dK:=Discriminant(Integers(K));
 DH:=Factorization(Discriminant(H));
 //First compute the mass of the principal genus
 MaxFact:=&*[dK^(m+1-2*j)*(-1)^(j*d)*2^-d*DedekindZetaExact(K,1-2*j)*&*([Norm(x[1])^j+(-1)^j: x in DH] cat [1]): j in [1..m]];
 DL:=Factorization(Discriminant(RL));
 DL:=[x: x in DL| not x[1] in [y[1]: y in DH]];
 res:=MaxFact;
 //Now for the local correction. For m=2,3 we have the correction factors hardcoded for performance reasons.
 if m eq 3 then
  for P in DL do
   res*:=Label(L,P[1]) in {2,3} select Norm(P[1])^4+Norm(P[1])^2+1 else 1;
  end for;
 end if;
 if m eq 2 then
  for P in DL do
   res*:=Label(L,P[1]) in {2} select Norm(P[1])^2+1 else 1;
  end for;
 end if;
 if m gt 3 then
  for P in DL do
   NP:=Norm(P[1]);
   hyp:=&*[(NP^(2*i)-1)/(NP-1): i in [1..m]]; //The index of an Iwahori subgroup in a hyperspecial subgroup.
   l:=Label(L,P[1]); //The Dynkin diagram corresponding to l is of type C_(l-1) x C_(m-l+1)
   para:=(&*[(NP^(2*i)-1)/(NP-1): i in [1..l-1]]) * (&*[(NP^(2*i)-1)/(NP-1): i in [1..m-l+1]]);
   res*:=hyp/para;
  end for;
 end if;
 return res;
end intrinsic;

intrinsic MassSP(F::Tup)->FldRatElt
 {The same as above but for a tuple of lattices}
 H:=BaseRing(GeneratingMatrix(F[1]));
 DDH:=Divisors(Discriminant(H));
 BP:=&join[BadPrimes(RegularLattice(x)): x in F];
 BP:={P: P in BP | not P in DDH};
 m:=Dimension(RegularLattice(F[1])) div 4;
 K:=AbsoluteField(BaseField(H));
 d:=Degree(K);
 dK:=Discriminant(Integers(K));
 FDH:=Factorization(Discriminant(H));
 //First compute the mass of the principal genus
 MaxFact:=&*[dK^(m+1-2*j)*(-1)^(j*d)*2^-d*DedekindZetaExact(K,1-2*j)*&*([Norm(x[1])^j+(-1)^j: x in FDH] cat [1]): j in [1..m]];
 res:=MaxFact;
 for P in BP do
  NP:=Norm(P);
  hyp:=&*[(NP^(2*i)-1)/(NP-1): i in [1..m]]; //The index of an Iwahori subgroup in a hyperspecial subgroup.
  l:=Label(F,P);
  l:=Sort(Setseq(l));
  para:=(&*([(NP^(2*i)-1)/(NP-1): i in [1..l[1]-1]] cat [1]));
  for j in [1..#l-1] do //We will multiply all the Poincare polynomials of the connected components of Cm~ - Label(F,P) 
   para*:=(&*([(NP^(i+1)-1)/(NP-1): i in [1..l[j+1]-l[j]-1]] cat [1]));
  end for;
  if l[#l] ne m+1 then
   para*:=(&*[(NP^(2*i)-1)/(NP-1): i in [1..m+1-l[#l]]]);
  end if;
  res*:=hyp/para;
 end for;

 return res;
end intrinsic;

intrinsic ComputeGenus(L::HermLat:MaxNorm:=100,Prime:=false,Mass:=0)->SeqEnum
 {Lists representatives for the genus of L.}
 m:=Ncols(GeneratingMatrix(L));
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 DH:=Divisors(Discriminant(H));
 if Type(Prime) eq RngOrdIdl then
  P:=Prime;
 else
  Primes:=PrimesUpTo(MaxNorm,K);
  P:=Primes[1];
  i:=1;
  while not (Label(L,P) eq 1 and not P in DH) do
   i:=i+1;
   if i gt #Primes then break; end if;
   P:=Primes[i];
  end while;
 end if;
 
 if not (Label(L,P) eq 1 and not P in DH and IsPrime(P)) then
  error "No suitable prime ideal found, try a higher maximal norm or specify another ideal";
 end if;
 _,splitting,emb:=pMatrixRing(O,P);
 time KR:=CosetRepresentatives(P,m,"0");
 ML:=Mass eq 0 select MassSP(L) else Mass;
 Genus:=[<L,MatrixRing(Codomain(emb),2*m)!1,P>];
 GenusStabs:=[UStab(L)];
 ml:=&+[1/#S: S in GenusStabs];
 CompleteGenus:=ml eq ML;
 ToDo:=Genus;

 while #ToDo gt 0 do
  M:=ToDo[1];
  LM:=M[1];
  gM:=M[2];
  Exclude(~ToDo,M);
  for j in [1..#KR] do
   kr:=KR[j];
   NL:=ConstructNeighbour(LM,gM^-1*EmbedMatrix(kr,emb)*gM,P,splitting);
   found:=false;
    for i in [1..#Genus] do
       if IsUIsomorphic(NL,Genus[i][1]) then
        found:=true;
        break i;
       end if;
    end for;
   
   if not found then
    Append(~Genus,<NL,EmbedMatrix(KR[j],emb)*gM,P>);
    Append(~ToDo,<NL,EmbedMatrix(KR[j],emb)*gM,P>);
    Append(~GenusStabs,UStab(NL));
    CompleteGenus:=&+[1/#x: x in GenusStabs] eq ML;
    print "New lattice found, mass left: ", ML-&+[1/#x: x in GenusStabs];
    if CompleteGenus then ToDo:=[]; break j; end if;
   end if; 
  end for;
 end while;
 if not CompleteGenus then //In principle it could happen that the neighbourship graph is not connected.
  print "Attention: No complete system of representatives found at this prime. Please try another ideal.";
 end if;
 return Genus;
end intrinsic;


intrinsic ComputeGenus(F::Tup : MaxNorm:=100,Prime:=false,Mass:=0)->SeqEnum
 {Lists representatives for the genus of F. We suppose that F is a facet of the building at all primes}
 L:=F[1];
 m:=Ncols(GeneratingMatrix(L));
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 DH:=Divisors(Discriminant(H));
 if Type(Prime) eq RngOrdIdl then
  P:=Prime;
 else
  Primes:=PrimesUpTo(MaxNorm,K);
  P:=Primes[1];
  i:=1;
  while not (Label(F,P) eq {1} and not P in DH) do
   i:=i+1;
   if i gt #Primes then break; end if;
   P:=Primes[i];
  end while;
 end if;
 
 if not (Label(F,P) eq {1} and not P in DH and IsPrime(P)) then
  error "No suitable prime ideal found, try a higher maximal norm or specify another ideal";
 end if;
 _,splitting,emb:=pMatrixRing(O,P);
 time KR:=CosetRepresentatives(P,m,"0");
 MF:=Mass eq 0 select MassSP(F) else Mass;
 Genus:=[<F,MatrixRing(Codomain(emb),2*m)!1,P>];
 GenusStabs:=[UStab(F)];
 mF:=&+[1/#S: S in GenusStabs];
 CompleteGenus:=mF eq MF;
 ToDo:=Genus;

 while #ToDo gt 0 do
  M:=ToDo[1];
  FM:=M[1];
  gM:=M[2];
  Exclude(~ToDo,M);
  for j in [1..#KR] do
   kr:=KR[j];
   NF:=<ConstructNeighbour(LM,gM^-1*EmbedMatrix(kr,emb)*gM,P,splitting): LM in FM>;
   found:=false;
    for i in [1..#Genus] do
       if IsUIsomorphic(NF,Genus[i][1]) then
        found:=true;
        break i;
       end if;
    end for;
   
   if not found then
    Append(~Genus,<NF,EmbedMatrix(KR[j],emb)*gM,P>);
    Append(~ToDo,<NF,EmbedMatrix(KR[j],emb)*gM,P>);
    Append(~GenusStabs,UStab(NF));
    CompleteGenus:=&+[1/#x: x in GenusStabs] eq MF;
    print "New lattice found, mass left: ", MF-&+[1/#x: x in GenusStabs];
    if CompleteGenus then ToDo:=[]; break j; end if;
   end if; 
  end for;
 end while;
 if not CompleteGenus then //In principle it could happen that the neighbourship graph is not connected.
  print "Attention: No complete system of representatives found at this prime. Please try another ideal.";
 end if;
 return Genus;
end intrinsic;








intrinsic FullActionStandardMethod(disc::RngOrdIdl,P::RngOrdIdl,m::RngIntElt,Rho::Map)->SeqEnum
 {Computes the action of all fundamental Hecke operators at P of the principle genus and with weight Rho with discriminant disc in dimension m via the Standard Method}
 if not IsPrime(P) or P in Divisors(disc)  then
  error "Not possible for this combination";
 end if;
 K:=NumberField(FieldOfFractions(Order(P)));
 H:=QuaternionAlgebra(disc,RealPlaces(K));
 V:=RSpace(H,m);
 B:=MatrixRing(H,m)!1;
 L:=HermitianLattice(B);
 h,gen:=HeckeOperator(L,P,1,Rho);
 res:=[h];
 for i in [2..m] do
  h:=HeckeOperator(L,P,i,Rho : Genus:=gen); //By specifying the genus we make sure that all operators are computed w.r.t. the same basis.
  Append(~res,h);
 end for;
 return res;
end intrinsic;

intrinsic FullActionEichlerMethod(L::HermLat,P::RngOrdIdl,Rho::Map : InvariantForm:=MatrixRing(Rationals(),1)!1)->SeqEnum
 {Computes the action of all fundamental Hecke operators at P of the principle genus with discriminant disc in dimension m and weight given by Rho via the Eichler Method}
 
 if not IsPrime(P) or not Label(L,P) eq 1 then
  error "Not possible for this combination";
 end if;
 m:=Ncols(GeneratingMatrix(L));
 K:=NumberField(FieldOfFractions(Order(P)));
 /*H:=QuaternionAlgebra(disc,RealPlaces(K));
 V:=RSpace(H,m);
 B:=MatrixRing(H,m)!1;
 L:=HermitianLattice(B);*/

 NP:=Norm(P);
 res:=[];
 
 if m eq 2 then
  R1:=IntertwiningOperator(L,P,2,Rho : InvariantForm:=InvariantForm);
  if not assigned R1`Peterson1 then
   error "For this method to be applicable, you need to specify an invariant form";
  end if;
  G1:=R1`Genus1;
  T:=R1`T12;
  TT:=R1`T21;
  I:=MatrixRing(Rationals(),Nrows(T))!1; 
  Append(~res,T*TT-(NP^4-1)/(NP-1)*I);

  R2:=IntertwiningOperator(L,P,3,Rho : Genus1:=G1, InvariantForm:=InvariantForm);
  T:=R2`T12;
  TT:=R2`T21;
  Append(~res,T*TT-(NP^4-1)/(NP-1)*I-(NP+1)*res[1]);
 end if;
 
 if m eq 3 then
  R1:=IntertwiningOperator(L,P,2,Rho : InvariantForm:=InvariantForm);
  if not assigned R1`Peterson1 then
   error "For this method to be applicable, you need to specify an invariant form";
  end if;
  G1:=R1`Genus1;
  T:=R1`T12;
  TT:=R1`T21;
  I:=MatrixRing(Rationals(),Nrows(T))!1;
  Append(~res,T*TT-(NP^6-1)/(NP-1)*I);
 
  R2:=IntertwiningOperator(L,P,3,Rho : Genus1:=G1, InvariantForm:=InvariantForm);
  T:=R2`T12;
  TT:=R2`T21;
  Append(~res,T*TT-(NP^7+NP^6+2*(NP^5+NP^4+NP^3+NP^2)+NP+1)*I-(NP^4-1)/(NP-1)*res[1]);

  R3:=IntertwiningOperator(L,P,4,Rho : Genus1:=G1, InvariantForm:=InvariantForm);
  T:=R3`T12;
  TT:=R3`T21;
  Append(~res,T*TT-(NP^6+NP^5+NP^4+2*NP^3+NP^2+NP+1)*I-(NP^4-1)/(NP-1)*res[1]-(NP+1)*res[2]);
 end if;
 
 return res;
 
end intrinsic;

intrinsic BasisOfRepresentationInvariants(G::GrpMat,Rho::Map)->SeqEnum
 {Given a matrix group G and a representation Rho of G compute a basis for the space of invariants of Rho(G)}
 GG:=[Rho(x): x in Generators(G)];
 K:=BaseRing(GG[1]);
 d:=Ncols(GG[1]);
 M:=MatrixRing(K,d);
 return Basis(&meet[Kernel(M!x-1): x in GG]);
end intrinsic;

intrinsic DimensionOfFormSpace(L::HermLat,Rho::Map)->RngIntElt,SeqEnum
 {Computes the dimension of the space of algebraic modular forms of level describes by L and weight given by the representation Rho (The Genus is computed in the process)}
 GL:=ComputeGenus(L);
 UGL:=[UStab(x[1]): x in GL];
 return &+[#BasisOfRepresentationInvariants(G,Rho): G in UGL],GL;
end intrinsic;

intrinsic BasisOfFormSpace(L::HermLat,Rho::Map)->SeqEnum,SeqEnum
 {Computes the space of algebraic modular forms of level describes by L and weight given by the representation Rho (The Genus is computed in the process)}
 GL:=ComputeGenus(L);
 UGL:=[UStab(x[1]): x in GL];
 return [BasisOfRepresentationInvariants(G,Rho): G in UGL],GL;
end intrinsic;

intrinsic HeckeOperator(L::HermLat, P::RngOrdIdl, w::MonStgElt, Rho::Map : Genus:=[], InvariantForm:=MatrixRing(Integers(),1)!1)->Mtrx,SeqEnum,SeqEnum
 {Computes the Heckeoperator described by the word w at P of Level Stab(L) and weight Rho, the user may hand over the genus or a U-invariant form in which case a Gram matrix for the Peterson inner product will also be computed.}

 if Label(L,P) eq 0 then
  error "Not a maximal integral form.";
 end if;
 m:=Ncols(GeneratingMatrix(L)); 
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 _,splitting,emb:=pMatrixRing(O,P);
 KP:=Codomain(emb);
 
 KR:=CosetRepresentatives(P,m,w);

 ML:=MassSP(L);
 //We implement two procedures one where the genus is already known and one where it is computed along the way"
 if #Genus gt 0 then
  GenusStabs:=[UStab(x[1]): x in Genus];
  if &+[1/#x: x in GenusStabs] ne ML then
   error "This is not a system of representatives for the genus";
  end if;
  InvBas:=[BasisOfRepresentationInvariants(G,Rho): G in GenusStabs];
  InvBasMat:=[*Matrix(x): x in InvBas*];
  Images:=[];// The [k,i,j] Entry of Images will be the image of L_k under the (i,j)-basis-function (which maps L_i to InvBas[i][j] and all other reps to zero).
 
  //We allow the prime at which we have constructed the genus to differ from P:
  P2:=Genus[1][3];
  if P2 ne P then 
   _,splitting2,emb2:=pMatrixRing(O,P2);
  end if;
 
  for i in [1..#Genus] do
   gM:=Genus[i][2];
   LM:=Genus[i][1];
   ImageList:=[[Parent(InvBas[m][1])!0: n in [1..#InvBas[m]]]: m in [1..#Genus]]; //This will later contain (in order) the images of mu_i (corresponding to Genus[i]) under the basis-function (m,n) which maps Genus[m] to InvBas[m][n] and the other reps to zero.
   for r in [1..#KR] do
    kr:=KR[r];
    if P eq P2 then
     NL:=ConstructNeighbour(L,EmbedMatrix(kr,emb)*gM,P,splitting); //If we computed the reps at P we can construct the lattice L*kr*gM directly otherwise we need to work at the two primes seperatly
    else
     NL:=ConstructNeighbour(L,EmbedMatrix(kr,emb),P,splitting);
     NL:=ConstructNeighbour(NL,gM,P2,splitting2);
    end if;
   
    for j in [1..#Genus] do
     b,g:=IsUIsomorphic(NL,Genus[j][1]);
     if b then
      gg:=Rho(QuatToRegular(g));
      for n in [1..#ImageList[j]] do
      ImageList[j][n]+:=InvBas[j][n]*gg;
      end for;
      break j;
     end if;
    end for;
   end for;
   Append(~Images,ImageList);
  end for;

 else
  //This is the method where the genus is computed along the way.
  Genus:=[<L,MatrixRing(KP,2*m)!1,P>];
  GenusStabs:=[UStab(x[1]): x in Genus];
  V:=VectorSpace(Parent(Rho(GenusStabs[1]!1)));
  B1:=[V!v: v in BasisOfRepresentationInvariants(GenusStabs[1],Rho)];
  InvBas:=[B1];
  InvBasMat:=[*Matrix(x): x in InvBas | #x ne 0*];
  Images:=[];// The [k,i,j] Entry of Images will be the image of mu_k (corresponding to the k-th lattice in genus(L)) under the (i,j)-basis-function
 

  ToDo:=Genus;
  
  while #ToDo gt 0 do
   gM:=ToDo[1][2];
   LM:=ToDo[1][1];
   i:=Position(Genus,ToDo[1]);
   Remove(~ToDo,1);
   ImageList:=[[Parent(InvBas[m][1])!0: n in [1..#InvBas[m]]]: m in [1..#Genus]];
   for r in [1..#KR] do
    kr:=KR[r];
    NL:=ConstructNeighbour(L,EmbedMatrix(kr,emb)*gM,P,splitting); 
    found:=false;
    for j in [1..#Genus] do
     b,g:=IsUIsomorphic(NL,Genus[j][1]);
     if b then
      found:=true;
      gg:=Rho(QuatToRegular(g));
      for n in [1..#ImageList[j]] do
       ImageList[j][n]+:=InvBas[j][n]*gg;
      end for;
      break j;
     end if;
    end for;
    if not found then
     Append(~Genus,<NL,EmbedMatrix(kr,emb)*gM,P>);
     Append(~ToDo,<NL,EmbedMatrix(kr,emb)*gM,P>);
     Append(~GenusStabs,UStab(NL));
     print "New isometry class found. Mass left: ", ML-&+[1/#x: x in GenusStabs];
     h:=#Genus;
     Append(~InvBas,BasisOfRepresentationInvariants(GenusStabs[h],Rho));
     if #InvBas[h] gt 0 then
      Append(~InvBasMat,Matrix(InvBas[h]));
     end if;
     Append(~ImageList,InvBas[h]);
     for k in [1..#Images] do
      Append(~Images[k],[Parent(InvBas[h][1])!0: l in [1..#InvBas[h]]]);
     end for;
    end if; 
   end for;
   Append(~Images,ImageList);
  end while;

 end if;

 Res:=[];
 for i in [1..#Genus] do
  for j in [1..#InvBas[i]] do
   row:=[];
   for k in [1..#Genus] do
    row cat:=Eltseq(Solution(InvBasMat[k],Images[k][i][j]));
   end for;
   Append(~Res,row);
  end for;
 end for;

 //Compute the gram matrix of the peterson inner product with respect to the basis specified by Genus and InvBas.
 if Nrows(InvariantForm) eq Nrows(Rho(GenusStabs[1]!1)) and #Res gt 0 then
  Pet:=[];
  InvariantForm:=ChangeRing(InvariantForm,K);
  for i in [1..#Genus] do
   for j in [1..#InvBas[i]] do
    for ii in [1..#Genus] do
     for jj in [1..#InvBas[ii]] do
      Append(~Pet,&+([K!0] cat [1/#GenusStabs[k]*(InvBas[i][j]*InvariantForm*Transpose(Matrix(InvBas[ii][jj])))[1][1]    :k in [1..#Genus] | k eq i and k eq ii]));
     end for;
    end for;
   end for;
  end for;
  Pet:=MatrixRing(K,#Res)!(Pet);   
  return Matrix(Res),Genus,InvBas,Pet;
 end if;
 if #Res eq 0 then
  return [],Genus,InvBas,_;
 else
  return Matrix(Res),Genus,InvBas,_;
 end if;
     
end intrinsic;

intrinsic IntertwiningOperator(L::HermLat, P::RngOrdIdl, gen2::RngIntElt,Rho::Map : Genus1:=[], Genus2:=[], InvariantForm:=MatrixRing(Integers(),1)!1)->Rec
 {Computes the intertwining operator from genus 2 to genus L (for technical reasons this way around) at the prime P. If an invariant form is given the adjoint operator is also computed.}
 if #Genus1 eq 0 or &+[1/#UStab(x[1]): x in Genus1] ne MassSP(L) then
  Genus1:=ComputeGenus(L);
 end if;
 
 m:=Ncols(GeneratingMatrix(L)); 
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 _,splitting,emb:=pMatrixRing(O,P);
 KP:=Codomain(emb);
 //The representatives need not have been computed at P:
 P2:=Genus1[1][3];
 _,splitting2,emb2:=pMatrixRing(O,P2);


 GenusStabs1:=[UStab(x[1]): x in Genus1];
 InvBas1:=[BasisOfRepresentationInvariants(G,Rho): G in GenusStabs1]; 
 V:=VectorSpace(Parent(Rho(GenusStabs1[1]!1)));
 InvBas1:=[[V!v: v in list]: list in InvBas1];
 InvBasMat1:=[*Matrix(x): x in InvBas1 | #x ne 0*];
 Images:=[]; //Images[k][i][j] will later be the image of Genus1_k when evaluated at the (i,j)-basis function of the form space with respect to genus2
 
 if Label(L,P) eq 1 then
  
  p:=UniformizingElement(KP);
  BBP2:=DiagonalMatrix(&cat[[KP!p,1]: i in [1..gen2-1]] cat [1: i in [1..2*m-2*(gen2-1)]]);  
  L2:=ConstructNeighbour(L,BBP2,P,splitting);
  Genus2:=[<L2,MatrixRing(KP,2*m)!1,P>];
  GenusStabs2:=[UStab(L2)];
  InvBas2:=[[V!v: v in BasisOfRepresentationInvariants(GenusStabs2[1],Rho)]];
  InvBasMat2:=[*Matrix(x): x in InvBas2*];
  ML2:=MassSP(L2);
  ml2:=&+[1/#S: S in GenusStabs2];
  KR2:=IntertwiningCosetRepresentatives(P,m,Label(L,P),gen2);

 
  for k in [1..#Genus1] do
   ImageList:=[[Parent(InvBas2[m][1])!0: n in [1..#InvBas2[m]]]: m in [1..#Genus2]];
   BG:=Genus1[k][1];
   MG:=Genus1[k][2];
   for j in [1..#KR2] do
    r:=EmbedMatrix(KR2[j],emb);
    if P2 eq P then
     NBp:=BBP2*r*MG; //This runs through the lattices of type gen2 in BG
     NL2:=ConstructNeighbour(L,NBp,P,splitting);
    else
     NL2:=ConstructNeighbour(L,BBP2*r,P,splitting);
     NL2:=ConstructNeighbour(NL2,MG,P2,splitting2);
    end if;
    
    found:=false;
    for i in [1..#Genus2] do
     b,g:=IsUIsomorphic(NL2,Genus2[i][1]); 
     if b then 
      found:=true;
      gg:=Rho(QuatToRegular(g));
      for n in [1..#ImageList[i]] do
       ImageList[i][n]+:=InvBas2[i][n]*gg;
      end for;
      break i;
     end if;
    end for;
    if not found then
     Append(~Genus2,<NL2,MatrixRing(KP,2*m)!0,P>); //0 still needs to be corrected.
     Append(~GenusStabs2,UStab(NL2));
     print "New isometry class in second genus found. Mass left: ", ML2-&+[1/#x: x in GenusStabs2];
     h:=#Genus2;
     Append(~InvBas2,BasisOfRepresentationInvariants(GenusStabs2[h],Rho));
     if #InvBas2[h] gt 0 then
      Append(~InvBasMat2,Matrix(InvBas2[h]));
     end if;
     Append(~ImageList,InvBas2[h]);
     for m in [1..#Images] do
      Append(~Images[m],[Parent(InvBas2[h][1])!0: l in [1..#InvBas2[h]]]);
     end for;
    end if;
   end for;
   Append(~Images,ImageList);
  end for;
  T21:=[];
  for i in [1..#Genus2] do
   for j in [1..#InvBas2[i]] do
    row:=[];
    for k in [1..#Genus1] do
     row cat:=Eltseq(Solution(InvBasMat1[k],Images[k][i][j]));
    end for;
    Append(~T21,row);
   end for;
  end for;
  T21:=Matrix(T21);
  //Compute the gram matrix of the peterson inner product(s) with respect to the basis specified by Genus1/2 and InvBas1/2.
  if Nrows(InvariantForm) eq Nrows(Rho(GenusStabs1[1]!1)) then
   Pet1:=[];
   InvariantForm:=ChangeRing(InvariantForm,K);
   for i in [1..#Genus1] do
    for j in [1..#InvBas1[i]] do
     for ii in [1..#Genus1] do
      for jj in [1..#InvBas1[ii]] do
       Append(~Pet1,&+([K!0] cat [1/#GenusStabs1[k]*(InvBas1[i][j]*InvariantForm*Transpose(Matrix(InvBas1[ii][jj])))[1][1]    :k in [1..#Genus1] | k eq i and k eq ii]));
      end for;
     end for;
    end for;
   end for;
   Pet1:=MatrixRing(K,Nrows(Transpose(T21)))!(Pet1);

   Pet2:=[];
   for i in [1..#Genus2] do
    for j in [1..#InvBas2[i]] do
     for ii in [1..#Genus2] do
      for jj in [1..#InvBas2[ii]] do
       Append(~Pet2,&+([K!0] cat [1/#GenusStabs2[k]*(InvBas2[i][j]*InvariantForm*Transpose(Matrix(InvBas2[ii][jj])))[1][1]    :k in [1..#Genus2] | k eq i and k eq ii]));
      end for;
     end for;
    end for;
   end for;
   Pet2:=MatrixRing(K,Nrows(T21))!(Pet2);

   T12:=Transpose(Pet2^-1*T21*Pet1);
   return rec<IO|T12:=T12,T21:=T21,Peterson1:=Pet1,Peterson2:=Pet2,Genus1:=Genus1,Genus2:=Genus2,FormSpaceBasis1:=InvBas1,FormSpaceBasis2:=InvBas2>;
  end if;
  return rec<IO|T21:=T21,Genus1:=Genus1,Genus2:=Genus2,FormSpaceBasis1:=InvBas1,FormSpaceBasis2:=InvBas2>;

 end if;
end intrinsic;

intrinsic GenusSymbol(L::HermLat)->Rec
 {Computes a description of the genus of L, where L defines a maximal integral form}
 m:=Ncols(GeneratingMatrix(L)); 
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 disc:=Discriminant(H);
 labels:=[];
 RL:=RegularLattice(L);
 DRL:=Dual(RL);
 require RL subset DRL: "This lattice does not define a maximal integral form.";
 
 ED:=ElementaryDivisors(Module(DRL),Module(RL));
 ED:=&cat[Factorization(x): x in ED];
 for P in ED do
  if not IsIntegral(disc/(P[1])) then
   l:=Label(L,P[1]);
   require l ne 0: "This lattice does not define a maximal integral form.";
   Append(~labels,<P[1],l>);
  end if;
 end for;
 return rec<GS |Dimension:=m, Discriminant:=disc,Labels:=labels>; 
end intrinsic;

intrinsic GenusRepresentative(GS::Rec)->HermLat
 {Computes one representative of the genus described by the genus symbol GS}
 disc:=GS`Discriminant;
 m:=GS`Dimension;
 R:=Order(disc);
 K:=NumberField(R);
 H:=QuaternionAlgebra(disc,RealPlaces(K));
 B:=MatrixRing(H,m)!1;
 L:=HermitianLattice(B); //A representative of the principal genus
 O:=DefiningOrder(L);
 Labels:=GS`Labels;
 for x in Labels do
  P:=x[1];
  _,splitting,emb:=pMatrixRing(O,P);
  KP:=Codomain(emb);
  p:=UniformizingElement(KP);
  BP:=DiagonalMatrix(&cat[[KP!p,1]: i in [1..x[2]-1]] cat [1: i in [1..2*m-2*(x[2]-1)]]); 
  L:=ConstructNeighbour(L,BP,P,splitting);
 end for;
 return L;
end intrinsic; 

intrinsic SteinbergComputation(disc::RngOrdIdl, Dimension::RngIntElt, IwahoriPrime::RngOrdIdl, OperatorPrimes::SeqEnum, Rho::Map : InvariantForm:=MatrixRing(Integers(),1)!1, Genus:=[],IwahoriOps:=[])->Rec
 {Computes the Steinberg subspace of the space of algebraic modular forms of weight given by an Iwahorisubgroup at the prime Iwahoriprime and hyperspecials elsewhere and the actions of the Hecke algebras at the primes in Operatorprimes on this subspace.}
 if #Genus eq 0 then
  K:=NumberField(Order(disc));
  m:=Dimension;
  P:=IwahoriPrime;
  H:=QuaternionAlgebra(disc,RealPlaces(K));
  B:=MatrixRing(H,m)!1;
  L:=HermitianLattice(B);
  O:=DefiningOrder(L);
  _,splitting,emb:=pMatrixRing(O,P);
  KP:=Codomain(emb);
  p:=UniformizingElement(KP);
  I:=<L>;
  for i in [1..m] do
   BP:=DiagonalMatrix(&cat[[KP!p,1]: j in [1..i]] cat [1: j in [1..2*m-2*i]]); 
   Append(~I,ConstructNeighbour(L,BP,P,splitting));
  end for;
  Genus:=ComputeGenus(I);

 else 

  K:=NumberField(Order(disc));
  m:=Dimension;
  P:=IwahoriPrime;
  I:=Genus[1][1];
  L:=I[1];
  O:=DefiningOrder(L);
  _,splitting,emb:=pMatrixRing(O,P);
  KP:=Codomain(emb);
  p:=UniformizingElement(KP);
 end if;
 //Now the tuple I represents an Iwahori at P and a hyperspecial everywhere else.
 
 //Now we compute the action of the generators of the Iwahori-subalgebra.
 P2:=Genus[2][3];
 _,splitting2,emb2:=pMatrixRing(O,P2);
 GenusStabs:=[UStab(x[1]): x in Genus];
 V:=VectorSpace(Parent(Rho(GenusStabs[1]!1)));
 //B1:=[V!v: v in BasisOfRepresentationInvariants(GenusStabs[1],Rho)];
 InvBas:=[[V!v: v in BasisOfRepresentationInvariants(GenusStabs[i],Rho)]: i in [1..#Genus]];
 InvBasMat:=[*Matrix(x): x in InvBas | #x ne 0*];


 if #IwahoriOps eq 0 then
  for k in [0..m] do
   Images:=[];// The [k,i,j] Entry of Images will be the image of mu_k (corresponding to the k-th lattice in genus(L)) under the (i,j)-basis-function
   ToDo:=Genus;
   KR:=CosetRepresentatives(P,m,[k],{0..m});  
   while #ToDo gt 0 do
    gM:=ToDo[1][2];
    LM:=ToDo[1][1];
    i:=Position(Genus,ToDo[1]);
    Remove(~ToDo,1);
    ImageList:=[[Parent(InvBas[x][1])!0: n in [1..#InvBas[x]]]: x in [1..#Genus]];
    for r in [1..#KR] do
     kr:=KR[r];
     NL:=<ConstructNeighbour(I[j],EmbedMatrix(kr,emb),P,splitting): j in [1..m+1]>; 
     NL:=<ConstructNeighbour(NL[j],gM,P2,splitting2): j in [1..m+1]>; 
     found:=false;
     for j in [1..#Genus] do
      b,g:=IsUIsomorphic(NL,Genus[j][1]);
      if b then
       found:=true;
       gg:=Rho(QuatToRegular(g));
       for n in [1..#ImageList[j]] do
        ImageList[j][n]+:=InvBas[j][n]*gg;
       end for;
       break j;
      end if;
     end for;
     if not found then
      Append(~Genus,<NL,EmbedMatrix(kr,emb)*gM,P>);
      Append(~ToDo,<NL,EmbedMatrix(kr,emb)*gM,P>);
      Append(~GenusStabs,UStab(NL));
      //print "New isometry class found. Mass left: ", ML-&+[1/#x: x in GenusStabs];
      h:=#Genus;
      Append(~InvBas,BasisOfRepresentationInvariants(GenusStabs[h],Rho));
      if #InvBas[h] gt 0 then
       Append(~InvBasMat,Matrix(InvBas[h]));
      end if;
      Append(~ImageList,InvBas[h]);
      for t in [1..#Images] do
       Append(~Images[t],[Parent(InvBas[h][1])!0: l in [1..#InvBas[h]]]);
      end for;
     end if; 
    end for;
    Append(~Images,ImageList);
   end while;  
 
  
 
   Res:=[];
   for i in [1..#Genus] do
    for j in [1..#InvBas[i]] do
     row:=[];
     for k in [1..#Genus] do
      row cat:=Eltseq(Solution(InvBasMat[k],Images[k][i][j]));
     end for;
     Append(~Res,row);
    end for;
   end for;
   Append(~IwahoriOps,Matrix(Res));
   print "Operator ", k, " done.";
  end for;
 end if;
 /*if Dimension(&meet [Kernel(x+1): x in IwahoriOps]) eq 0 then
  print "Trivial Steinberg space.";
  return IwahoriOps,Genus,_;
 end if;*/
 //print &meet [Kernel(x+1): x in IwahoriOps];
 OPOps:=[];
 InvBas1:=InvBas;
 InvBasMat1:=InvBasMat;
 for Q in OperatorPrimes do
  _,splitting3,emb3:=pMatrixRing(O,Q);
  KQ:=Codomain(emb3);
  p:=UniformizingElement(KQ);
  for gen2 in [2..m+1] do
   Images:=[];
   BBQ:=DiagonalMatrix(&cat[[KQ!p,1]: i in [1..gen2-1]] cat [1: i in [1..2*m-2*(gen2-1)]]);  
   I2:=<ConstructNeighbour(N,BBQ,Q,splitting3): N in I>;
   Genus2:=[*<I2,MatrixRing(KQ,2*m)!1,Q>*];
   GenusStabs2:=[UStab(I2)];
   InvBas2:=[[V!v: v in BasisOfRepresentationInvariants(GenusStabs2[1],Rho)]];
   InvBasMat2:=[*Matrix(x): x in InvBas2*];
   ML2:=MassSP(I2);
   ml2:=&+[1/#S: S in GenusStabs2];
   KR2:=IntertwiningCosetRepresentatives(Q,m,1,gen2);
 
  
   for k in [1..#Genus] do
    ImageList:=[[Parent(InvBas2[m][1])!0: n in [1..#InvBas2[m]]]: m in [1..#Genus2]];
    BG:=Genus[k][1];
    MG:=Genus[k][2];
    for j in [1..#KR2] do
     r:=EmbedMatrix(KR2[j],emb3);
     if P2 eq Q then
      NBp:=BBQ*r*MG; //This runs through the lattices of type gen2 in BG
      NI2:=<ConstructNeighbour(N,NBp,Q,splitting3): N in I>;
     else
      NI2:=<ConstructNeighbour(N,BBQ*r,Q,splitting3): N in I>;
      NI2:=<ConstructNeighbour(N,MG,P2,splitting2): N in NI2>;
     end if;
     
     found:=false;
     for i in [1..#Genus2] do
      b,g:=IsUIsomorphic(NI2,Genus2[i][1]); 
      if b then 
       found:=true;
       gg:=Rho(QuatToRegular(g));
       for n in [1..#ImageList[i]] do
        ImageList[i][n]+:=InvBas2[i][n]*gg;
       end for;
       break i;
      end if;
     end for;
     if not found then
      Append(~Genus2,<NI2,MatrixRing(KP,2*m)!0,Q>); //0 still needs to be corrected.
      Append(~GenusStabs2,UStab(NI2));
      print "New isometry class in second genus found. Mass left: ", ML2-&+[1/#x: x in GenusStabs2];
      h:=#Genus2;
      Append(~InvBas2,BasisOfRepresentationInvariants(GenusStabs2[h],Rho));
      if #InvBas2[h] gt 0 then
       Append(~InvBasMat2,Matrix(InvBas2[h]));
      end if;
      Append(~ImageList,InvBas2[h]);
      for m in [1..#Images] do
       Append(~Images[m],[Parent(InvBas2[h][1])!0: l in [1..#InvBas2[h]]]);
      end for;
     end if;
    end for;
    Append(~Images,ImageList);
   end for;
   T21:=[];
   for i in [1..#Genus2] do
    for j in [1..#InvBas2[i]] do
     row:=[];
     for k in [1..#Genus] do
      row cat:=Eltseq(Solution(InvBasMat1[k],Images[k][i][j]));
     end for;
     Append(~T21,row);
    end for;
   end for;
   T21:=Matrix(T21);
   //Compute the gram matrix of the peterson inner product(s) with respect to the basis specified by Genus1/2 and InvBas1/2.
   
    Pet1:=[];
    InvariantForm:=ChangeRing(InvariantForm,K);
    for i in [1..#Genus] do
     for j in [1..#InvBas1[i]] do
      for ii in [1..#Genus] do
       for jj in [1..#InvBas1[ii]] do
        Append(~Pet1,&+([K!0] cat [1/#GenusStabs[k]*(InvBas1[i][j]*InvariantForm*Transpose(Matrix(InvBas1[ii][jj])))[1][1]    :k in [1..#Genus] | k eq i and k eq ii]));
       end for;
      end for;
     end for;
    end for;
    Pet1:=MatrixRing(K,Nrows(Transpose(T21)))!(Pet1);
 
    Pet2:=[];
    for i in [1..#Genus2] do
     for j in [1..#InvBas2[i]] do
      for ii in [1..#Genus2] do
       for jj in [1..#InvBas2[ii]] do
        Append(~Pet2,&+([K!0] cat [1/#GenusStabs2[k]*(InvBas2[i][j]*InvariantForm*Transpose(Matrix(InvBas2[ii][jj])))[1][1]    :k in [1..#Genus2] | k eq i and k eq ii]));
       end for;
      end for;
     end for;
    end for;
    Pet2:=MatrixRing(K,Nrows(T21))!(Pet2);
 
    T12:=Transpose(Pet2^-1*T21*Pet1);
    Append(~OPOps,T12*T21);
   end for; 
  end for;
 return IwahoriOps,OPOps,Genus;
end intrinsic;

intrinsic UniversalHeckeOperator(L::HermLat, P::RngOrdIdl, w::MonStgElt : Genus:=[])->SeqEnum,SeqEnum
 {Computes the universal Heckeoperator described by the word w at P of Level Stab(L), the user may hand over the genus.}

 if Label(L,P) eq 0 then
  error "Not a maximal integral form.";
 end if;
 m:=Ncols(GeneratingMatrix(L)); 
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 _,splitting,emb:=pMatrixRing(O,P);
 KP:=Codomain(emb);
 KR:=CosetRepresentatives(P,m,w);
 ML:=MassSP(L);
 KG:=GroupAlgebra(Rationals(),GL(4*m,Q));
 if #Genus eq 0 then
  Genus:=[<L,MatrixRing(KP,2*m)!1,P>];
 end if;
 P2:=Genus[1][3];
 if P2 ne P then 
  _,splitting2,emb2:=pMatrixRing(O,P2);
 end if;

 
 GenusStabs:=[UStab(x[1]): x in Genus];

 Sigmas:=[KG!1: x in Genus];
 Images:=[];// The [k,i] Entry of Images will be the image of mu_k (corresponding to the k-th lattice in genus(L)) under the (i)-basis-function
 ToDo:=Genus;
 
 while #ToDo gt 0 do
  gM:=ToDo[1][2];
  LM:=ToDo[1][1];
  i:=Position(Genus,ToDo[1]);
  Remove(~ToDo,1);
  ImageList:=[KG!0: m in [1..#Genus]];
  for r in [1..#KR] do
   kr:=KR[r];
   if P eq P2 then 
    NL:=ConstructNeighbour(L,EmbedMatrix(kr,emb)*gM,P,splitting);
   else
    NL:=ConstructNeighbour(L,EmbedMatrix(kr,emb),P,splitting);
    NL:=ConstructNeighbour(NL,gM,P2,splitting2); 
   end if;
   found:=false;
   for j in [1..#Genus] do
    b,g:=IsUIsomorphic(NL,Genus[j][1]);
    if b then
     found:=true;
     gg:=QuatToRegular(g);  
     ImageList[j]+:=Sigmas[j]*GL(4*m,Q)!gg;    
     break j;
    end if;
   end for;
   if not found then
    Append(~Genus,<NL,EmbedMatrix(kr,emb)*gM,P>);
    Append(~ToDo,<NL,EmbedMatrix(kr,emb)*gM,P>);
    Append(~GenusStabs,UStab(NL));
    print "New isometry class found. Mass left: ", ML-&+[1/#x: x in GenusStabs];
    h:=#Genus;
    Append(~Sigmas,KG!1);
    Append(~ImageList,Sigmas[h]);
    for k in [1..#Images] do
     Append(~Images[k],KG!0);
    end for;
   end if; 
  end for;
  Append(~Images,ImageList);
 end while;

 return Transpose(Matrix(Images)),Genus;
end intrinsic;



intrinsic UniversalIntertwiningOperator(L::HermLat, P::RngOrdIdl, gen2::RngIntElt: Genus1:=[], Genus2:=[])->Rec
 {Computes the intertwining operator from genus 2 to genus L (for technical reasons this way around) at the prime P. If an invariant form is given the adjoint operator is also computed.}
 if #Genus1 eq 0 or &+[1/#UStab(x[1]): x in Genus1] ne MassSP(L) then
  Genus1:=ComputeGenus(L);
 end if;
 
 m:=Ncols(GeneratingMatrix(L)); 
 O:=DefiningOrder(L);
 K:=BaseField(L); 
 H:=BaseRing(GeneratingMatrix(L));
 _,splitting,emb:=pMatrixRing(O,P);
 KP:=Codomain(emb);
 //The representatives need not have been computed at P:
 P2:=Genus1[1][3];
 _,splitting2,emb2:=pMatrixRing(O,P2);

 QG:=GroupAlgebra(Q,GL(4*m,Q));
 GenusStabs1:=[UStab(x[1]): x in Genus1];
 InvBas1:=[QG!1: x in Genus1]; 

 Images:=[]; //Images[k][i] will later be the image of Genus1_k when evaluated at the i-basis function of the form space with respect to genus2
 
 if Label(L,P) eq 1 then
  
  p:=UniformizingElement(KP);
  BBP2:=DiagonalMatrix(&cat[[KP!p,1]: i in [1..gen2-1]] cat [1: i in [1..2*m-2*(gen2-1)]]);  
  L2:=ConstructNeighbour(L,BBP2,P,splitting);
  Genus2:=[<L2,MatrixRing(KP,2*m)!1,P>];
  GenusStabs2:=[UStab(L2)];
  InvBas2:=[QG!1: x in GenusStabs2];
  ML2:=MassSP(L2);
  ml2:=&+[1/#S: S in GenusStabs2];
  KR2:=IntertwiningCosetRepresentatives(P,m,Label(L,P),gen2);

 
  for k in [1..#Genus1] do
   ImageList:=[QG!0: m in [1..#Genus2]];
   BG:=Genus1[k][1];
   MG:=Genus1[k][2];
   for j in [1..#KR2] do
    r:=EmbedMatrix(KR2[j],emb);
    if P2 eq P then
     NBp:=BBP2*r*MG; //This runs through the lattices of type gen2 in BG
     NL2:=ConstructNeighbour(L,NBp,P,splitting);
    else
     NL2:=ConstructNeighbour(L,BBP2*r,P,splitting);
     NL2:=ConstructNeighbour(NL2,MG,P2,splitting2);
    end if;
    
    found:=false;
    for i in [1..#Genus2] do
     b,g:=IsUIsomorphic(NL2,Genus2[i][1]); 
     if b then 
      found:=true;
      gg:=QuatToRegular(g);
      ImageList[i]+:=InvBas2[i]*GL(4*m,Q)!gg;
      break i;
     end if;
    end for;
    if not found then
     Append(~Genus2,<NL2,MatrixRing(KP,2*m)!0,P>); //0 still needs to be corrected.
     Append(~GenusStabs2,UStab(NL2));
     print "New isometry class in second genus found. Mass left: ", ML2-&+[1/#x: x in GenusStabs2];
     h:=#Genus2;
     Append(~InvBas2,QG!1);
     Append(~ImageList,InvBas2[h]);
     for m in [1..#Images] do
      Append(~Images[m],QG!0);
     end for;
    end if;
   end for;
   Append(~Images,ImageList);
  end for;
  T21:=Transpose(Matrix(Images));
  return rec<IO|T21:=T21,Genus1:=Genus1,Genus2:=Genus2,FormSpaceBasis1:=InvBas1,FormSpaceBasis2:=InvBas2>;

 end if;
end intrinsic;

intrinsic UniversalAdjoint(x::Mtrx,Genus1::SeqEnum,Genus2::SeqEnum)->Mtrx
 {The adjoint of the universal operator x: M(Genus1)->M(Genus2)}
 mat:=Transpose(Parent(x)!0);
 if not (Nrows(x) eq #Genus1 and Nrows(mat) eq #Genus2) then 
  error "Incompatible input";
 end if;

 S1:=[#UStab(x[1]): x in Genus1];
 S2:=[#UStab(x[1]): x in Genus2];
 for i in [1..Nrows(x)] do
  for j in [1..Nrows(mat)] do
   mat[j][i]:=S1[i]/S2[j]*GroupRingInvolution(x[i][j]);
  end for;
 end for;
 return mat;
end intrinsic;



intrinsic SpecializeOperator(x::Mtrx,Genus1::SeqEnum,Genus2::SeqEnum,Rho::Map)->Mtrx
 {x is a universal operator M(Genus1)->M(Genus2) and Rho a representation. Compute the specialization of x at Rho.}
 
 GenusStabs1:=[UStab(x[1]): x in Genus1];
 InvBas1:=[BasisOfRepresentationInvariants(G,Rho): G in GenusStabs1]; 
 V:=ChangeRing(VectorSpace(Parent(Rho(GenusStabs1[1]!1))),Rationals());
 dim:=Dimension(V);
 InvBas1:=[[V!v: v in list]: list in InvBas1];
 InvBasMat1:=[*Matrix(x): x in InvBas1 | #x ne 0*];

 GenusStabs2:=[UStab(x[1]): x in Genus2];
 InvBas2:=[BasisOfRepresentationInvariants(G,Rho): G in GenusStabs2]; 
 InvBas2:=[[V!v: v in list]: list in InvBas2];
 InvBasMat2:=[*Matrix(x): x in InvBas2 | #x ne 0*];

 T12:=[];
 Mdim:=MatrixRing(Rationals(),dim);
 Spx:=[[&+([t[1]*Mdim!Rho(t[2]): t in Eltseq(x[i][k])] cat [Mdim!0]): k in [1..#Genus2]]: i in [1..#Genus1]];

 for i in [1..#Genus1] do
  for j in [1..#InvBas1[i]] do
   row:=[];
   for k in [1..#Genus2] do
    row cat:=Eltseq(Solution(InvBasMat2[k],InvBas1[i][j]*Spx[i][k]));
   end for;
   Append(~T12,row);
  end for;
 end for;
 return Matrix(T12);
end intrinsic;





