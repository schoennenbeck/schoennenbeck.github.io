//Mainly conversion functions between the different representations
QQ:=Rationals();
ZZ:=Integers();

intrinsic GroupRingInvolution(x::AlgGrpElt)->AlgGrpElt
 {The natural involution on the GroupRing Parent(x)}
 if x eq Parent(x)!0 then 
  return Parent(x)!0; 
 end if;
 e:=Eltseq(x);
 e:=[<y[1],y[2]^-1>: y in e];
 RR:=Parent(x);
 return &+[y[1]*RR!y[2]: y in e];
end intrinsic;


intrinsic EmbedMatrix(M::Mtrx,F::Map)->Mtrx
{The image of M under F}
 L:=Parent(F(M[1][1]));
 res:=RMatrixSpace(L,NumberOfRows(M),NumberOfColumns(M))!0;
 for i in [1..NumberOfRows(M)] do
  for j in [1..NumberOfColumns(M)] do
   res[i][j]:=F(M[i][j]);
  end for;
 end for;
 return res;
end intrinsic;

intrinsic QuatToRegular(mat::Mtrx)->Mtrx
 {Takes a matrix over a quaternion algebra H and returns the regular representation}
 H:=BaseRing(mat);
 if not assigned H`RegularRepresentation then 
  RH,rh:=RegularRepresentation(H);
  H`RegularRepresentation:=rh;
 end if; 
 rh:=H`RegularRepresentation;
 m:=NumberOfRows(mat);
 n:=NumberOfColumns(mat);
 blocklist:=[rh(H!x): x in Eltseq(mat)];
 return BlockMatrix(m,n,blocklist);
end intrinsic;

intrinsic RegularToQuat(mat::Mtrx,H::AlgQuat)->Mtrx
 {The Inverse of the above function}
 require BaseRing(mat) eq BaseField(H): "Incompatible base fields.";
 require NumberOfRows(mat) eq NumberOfColumns(mat): "Please enter square matrix";
 require NumberOfRows(mat) mod 4 eq 0: "This is not the matrix of an element of a matrix ring of H";
 m:=ZZ!(NumberOfRows(mat)/4);
 MH:=MatrixRing(H,m);
 res:=MH!0;
 for i in [1..m] do
  for j in [1..m] do
   res[i][j]:=mat[4*(i-1)+1][4*(j-1)+1]*H!1+&+[mat[4*(i-1)+1][4*(j-1)+k+1]*H.k: k in [1..3]];
  end for;
 end for;
 return res;
end intrinsic;

intrinsic HermTr(mat::Mtrx)->Mtrx 
 {A hermitian-transpose for matrices over a quaternion algebra}
 MH:=Parent(mat);
 res:=MH!Transpose(mat);
 for i in [1..NumberOfRows(res)] do
  for j in [1..NumberOfColumns(res)] do
   res[i][j]:=Conjugate(res[i][j]);
  end for;
 end for;
 return res;
end intrinsic;

intrinsic IsInU(mat::Mtrx)->BoolElt
 {Tests whether mat lies in our compact form of Sp}
 return mat*HermTr(mat) eq Parent(mat)!1;
end intrinsic;

intrinsic IsInUReg(mat::Mtrx,H::AlgQuat)->BoolElt
 {Tests wheter a matrix in K^(4m x 4m) belongs to our form of Sp}
 z:=RegularToQuat(mat,H);
 return QuatToRegular(z) eq mat and IsInU(z);
end intrinsic;

intrinsic VectorToRegular(v::ModTupRngElt)->ModTupRngElt
 {Transforms a length m vector over H into a length 4m vector over the BaseRing of the quaternions over which v is defined}
 H:=BaseRing(v);
 return Vector(&cat[Eltseq(H!x): x in Eltseq(v)]);
end intrinsic;

intrinsic RegularToVector(v,H::AlgQuat)->ModTupRngElt
 {The inverse}
 ev:=Eltseq(v);
 require #ev mod 4 eq 0: "Enter vector of length 4*sth";\
 m:=ZZ!(#ev/4);
 V:=RSpace(H,m);
 res:=V!0;
 BH:=[H!1,H.1,H.2,H.3];
 for i in [1..m] do
  res[i]:=&+[ev[4*(i-1)+k]*BH[k]: k in [1..4]];
 end for;
 return res;
end intrinsic;

intrinsic SpToUMat(g)->Mtrx
 {}
 m:=Nrows(g) div 2;
 K:=BaseRing(g);
 V:=RowSpace((g));
 M2:=MatrixRing(K,2);
 MM:=MatrixRing(M2,m);
 res:=MM!0;
 for i in [1..m] do
  for j in [1..m] do
   t:=M2!0;
   t[1][1]:=(V.(2*i-1)*g)[2*j-1];
   t[1][2]:=(V.(2*i-1)*g)[2*j];
   t[2][1]:=(V.(2*i)*g)[2*j-1];
   t[2][2]:=(V.(2*i)*g)[2*j];
   res[i][j]:=t;
  end for;
 end for;
 return res;
end intrinsic;
 
